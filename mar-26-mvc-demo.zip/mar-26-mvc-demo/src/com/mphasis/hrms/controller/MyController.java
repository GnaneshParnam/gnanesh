package com.mphasis.hrms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/one")
	public String login()
	{
		return "login";
	}
	
	@RequestMapping("/validate")
	public String validate(String username,String password, ModelMap model) {
		
		model.addAttribute("username", username);
		return "home";
	}
}
